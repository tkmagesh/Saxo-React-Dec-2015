import {Employee} from './main';
let employee = new Employee("Magesh", "Kuppan");
console.log(employee.print());
console.log("client loaded");